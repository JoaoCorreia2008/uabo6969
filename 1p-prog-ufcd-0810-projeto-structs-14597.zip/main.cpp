#include <iostream>
#include <string>
#include <cmath>
#include <stdio.h>
#include <ctype.h>
#include <ctime>

using namespace std;
const int numModulosprogramacao = 6;
const int numModulosmatematica = 3;
const int numModulosportugues = 3;
const int numModulosingles = 3;
const int numModulosareadeintegracao = 2;
const int numModulostic = 4;
const int numModuloseducacaofisica = 6;
const int numModulosfisicaequimica = 6;
const int numModulosmicroprocessadoreseautomacao = 4;
const int numModulosredes = 2;
const int numModuloseducacaomoralereligiosa = 1;

struct Notas {
    string areaNome;
    string moduloNome[20];
    int moduloNota [20];
};
void mostramodulos (Notas x, int numModulos){
    for (int i=0; i<numModulos; i++){
        cout << x.moduloNome[i]<< endl;
        cout << x.moduloNota[i]<< endl;
        
    }
}

float mediaprogramacao(Notas & notasprogramacao){
    float media = 0;
    float notas = 0;
    for (int i = 0; i< numModulosprogramacao; i++){
        if (notasprogramacao.moduloNota[i] >= 10){
            media += notasprogramacao.moduloNota[i];
            notas++;
            }
        }
        if (notas > 0){
            return media / notas;
        }else {
            return 0;
        }
    }
    
int main () {
    Notas notasprogramacao;
    Notas notasmatematica;
    Notas notasportugues;
    Notas notasingles;
    Notas notasareadeintegracao;
    Notas notastic;
    Notas notaseducacaofisica;
    Notas notasfisicaequimica;
    Notas notasmicroprocessadoreseautomacao;
    Notas notasredes;
    Notas notaseducacaomoralereligiosa;
    int resposta;

    notasprogramacao.areaNome = "Programacao";
    notasprogramacao.moduloNome[0] = "algoritemia";
    notasprogramacao.moduloNome[1] = "Estrutura e Metodologias de Programacao";
    notasprogramacao.moduloNome[2] = "C++ - Fundamento ";
    notasprogramacao.moduloNome[3] = "C++ - Avancado ";
    notasprogramacao.moduloNome[4] = "Java ";
    notasprogramacao.moduloNome[5] = "Java web ";

    notasprogramacao.moduloNota[0]= 17;
    notasprogramacao.moduloNota[1]= 14;
    notasprogramacao.moduloNota[2]= 10;
    notasprogramacao.moduloNota[3]= 0;
    notasprogramacao.moduloNota[4]= 0;
    notasprogramacao.moduloNota[5]= 0;
    

    notasmatematica.areaNome = "Matematica";
    notasmatematica.moduloNome[0] = "Estatistica";
    notasmatematica.moduloNome[1] = "Funcoes Polinomiais";
    notasmatematica.moduloNome[2] = "Geometria";

    notasmatematica.moduloNota[0]= 13;
    notasmatematica.moduloNota[1]= 0;
    notasmatematica.moduloNota[2]= 0;
    
    notasingles.areaNome = "Ingles";
    notasingles.moduloNome[0] = "Eu e o Mundo Profissional";
    notasingles.moduloNome[1] = "Um Mundo de Muitas Linguas";
    notasingles.moduloNome[2] = "O Mundo Tecnologico";

    notasingles.moduloNota[0]= 11;
    notasingles.moduloNota[1]= 0;
    notasingles.moduloNota[2]= 0;
    
    notasportugues.areaNome = "Portugues";
    notasportugues.moduloNome[0] = "Contos populares";
    notasportugues.moduloNome[1] = "Frasa de Ines Pereira";
    notasportugues.moduloNome[2] = "Lusiadas";

    notasportugues.moduloNota[0]= 12;
    notasportugues.moduloNota[1]= 13;
    notasportugues.moduloNota[2]= 0;
    
    notasareadeintegracao.areaNome = "Area de Integracão";
    notasareadeintegracao.moduloNome[0] = "Modulo 1";
    notasareadeintegracao.moduloNome[1] = "Modulo 2";
    

    notasareadeintegracao.moduloNota[0]= 0;
    notasareadeintegracao.moduloNota[1]= 0;
    
    
    
    notastic.areaNome = "Tic";
    notastic.moduloNome[0] = "Introducao a modelacao 3D";
    notastic.moduloNome[1] = "Edicao de som e video";
    notastic.moduloNome[2] = "Organizacao e tratamento de dados";
    notastic.moduloNome[3] = "Pesquisar, filtrar e estruturar informacao e conteudos em ambientes digitais";
    
    notastic.moduloNota[0]= 14;
    notastic.moduloNota[1]= 0;
    notastic.moduloNota[2]= 0;
    notastic.moduloNota[3]= 0;
    
    notaseducacaofisica.areaNome = "Educacao Fisica";
    notaseducacaofisica.moduloNome[0] = "Jogos Desportivos Coletivos I";
    notaseducacaofisica.moduloNome[1] = "Ginastica I ";
    notaseducacaofisica.moduloNome[2] = "Atletismo / Raquetas / Patinagem I";
    notaseducacaofisica.moduloNome[3] = "Dança I";
    notaseducacaofisica.moduloNome[4] = "Aptidao fisica";
    notaseducacaofisica.moduloNome[5] = "Atividades fisicas / contextos e saude I";
    
    
    notaseducacaofisica.moduloNota[0]= 16;
    notaseducacaofisica.moduloNota[1]= 0;
    notaseducacaofisica.moduloNota[2]= 0;
    notaseducacaofisica.moduloNota[3]= 0;
    notaseducacaofisica.moduloNota[4]= 0;
    notaseducacaofisica.moduloNota[5]= 0;
    
    notasfisicaequimica.areaNome = "Fisica e Quimica";
    notasfisicaequimica.moduloNome[0] = "Forcas e Movimentos";
    notasfisicaequimica.moduloNome[1] = "Estatica";
    notasfisicaequimica.moduloNome[2] = "Hidrostatica e Hidrodinamica";
    notasfisicaequimica.moduloNome[3] = "Luz e Fontes de Luz";
    notasfisicaequimica.moduloNome[4] = "Otica geometrica";
    notasfisicaequimica.moduloNome[5] = "Circuitos eletricos";

    notasfisicaequimica.moduloNota[0]= 15;
    notasfisicaequimica.moduloNota[1]= 19;
    notasfisicaequimica.moduloNota[2]= 13;
    notasfisicaequimica.moduloNota[3]= 0;
    notasfisicaequimica.moduloNota[4]= 0;
    notasfisicaequimica.moduloNota[5]= 0;
    
    notasmicroprocessadoreseautomacao.areaNome = "Microprocessadores e Automacao";
    notasmicroprocessadoreseautomacao.moduloNome[0] = "Dispositivos e perifericos";
    notasmicroprocessadoreseautomacao.moduloNome[1] = "Sistemas operativos - tipologias";
    notasmicroprocessadoreseautomacao.moduloNome[2] = "Utilitarios";
    notasmicroprocessadoreseautomacao.moduloNome[3] = "Informatica - nocoes basicas";

    notasmicroprocessadoreseautomacao.moduloNota[0]= 14;
    notasmicroprocessadoreseautomacao.moduloNota[1]= 14;
    notasmicroprocessadoreseautomacao.moduloNota[2]= 0;
    notasmicroprocessadoreseautomacao.moduloNota[3]= 0;
 


    notasredes.areaNome = "Redes";
    notasredes.moduloNome[0] = "Conexoes de rede";
    notasredes.moduloNome[1] = "Sistemas de rede local";
    
    notasredes.moduloNota[0]= 14;
    notasredes.moduloNota[1]= 0;
    
    notaseducacaomoralereligiosa.areaNome = "Educacao Moral e Religiosa";
    notaseducacaomoralereligiosa.moduloNome[0] = "Modulo 1";
    
    notaseducacaomoralereligiosa.moduloNota[0]= 0;
do {
    cout <<  " ** BEM VINDO AO PROGRAMA ***" << endl;
    cout << "*** PERCURSO AO LONGO DO CURSO ***" << endl;
    cout << endl;
    cout << "O que pertendes fazer :" << endl;
    cout << "0 - sair" << endl;
    cout << "1 - Ver Modulos e notas" << endl;
    cout << "2 - Ver media dos Modulos" << endl;
    cout << "3 - Ver nota maxima dos Modulos" << endl;
    cout << "4 - Ver nota minima dos Modulos" << endl;
    cout << "5 - Ver nota mais elevada tirada no curso inteiro" << endl;
    cout << "6 - Ver nota mais baixa tirada no curso inteiro" << endl;
    cout << "7 - Ver media do curso inteiro"<< endl;
    cin >> resposta;
    switch(resposta){
    case 1:
            cout << endl << endl << "MODULOS DE PROGRAMACAO" << endl;
            mostramodulos(notasprogramacao, numModulosprogramacao);
        
            cout << endl << endl << "MODULOS DE MATEMATICA" << endl;
            mostramodulos(notasmatematica, numModulosmatematica);
            
            cout << endl << endl << "MODULOS DE INGLES" << endl;
            mostramodulos(notasingles, numModulosingles);
            
            cout << endl << endl << "MODULOS DE PORTUGUES" << endl;
            mostramodulos(notasportugues, numModulosportugues);
            
            cout << endl << endl << "MODULOS DE AREA DE INTEGRACAO" << endl;
            mostramodulos(notasareadeintegracao, numModulosareadeintegracao);
            
            cout << endl << endl << "MODULOS DE TIC" << endl;
            mostramodulos(notastic, numModulostic);
            
            cout << endl << endl << "MODULOS DE EDUCACAO FISICA" << endl;
            mostramodulos(notaseducacaofisica, numModuloseducacaofisica);
            
            cout << endl << endl << "MODULOS DE FISICA E QUIMICA" << endl;
            mostramodulos(notasfisicaequimica, numModulosfisicaequimica);
            
            cout << endl << endl << "MODULOS DE MICROPROCESSADORES E AUTOMACAO" << endl;
            mostramodulos(notasmicroprocessadoreseautomacao, numModulosmicroprocessadoreseautomacao);
            
            cout << endl << endl << "MODULOS DE REDES" << endl;
            mostramodulos(notasredes, numModulosredes);
            
            cout << endl << endl << "MODULOS DE EDUCACAO MORAL E RELIGIOSA" << endl;
            mostramodulos(notaseducacaomoralereligiosa, numModuloseducacaomoralereligiosa);
        break;
        
    case 2:
        do{
            cout << "De qual Modulo deseja ver a media :" << endl;
            cout << "0 - Nenhum" << endl;
            cout << "1 - PROGRAMACAO" << endl;
            cout << "2 - MATEMATICA" << endl;
            cout << "3 - PORTUGUES" << endl;
            cout << "4 - INGLES" << endl;
            cout << "5 - AREA DE INTEGRACAO" << endl;
            cout << "6 - TIC" << endl;
            cout << "7 - EDUCACAO FISICA"<< endl;
            cin >> resposta;
            switch(resposta){
                case 1:
                        cout << "A Media de PROGRAMACAO" << endl;
                        cout << "R:" << mediaprogramacao(notasprogramacao) << endl;
                    break;
            }
        }while (resposta = 0);
        
        break;
        
    case 3:
        break;
        
    case 4:
        break;
        
    case 5:
        break;
        
    case 6:
        break;
        
    case 7:
        break;
    }
}while (resposta != 0);
  
    



return 0;

    
}